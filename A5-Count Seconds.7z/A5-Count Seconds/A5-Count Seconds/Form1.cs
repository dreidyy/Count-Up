﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A5_Count_Seconds
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int counter = 0;

        private void btStart_Click(object sender, EventArgs e)
        {
            Tcount = new System.Windows.Forms.Timer();
            Tcount.Tick += new EventHandler(Tcount_Tick);
            Tcount.Interval = 1000; // 1 second
            Tcount.Start();
            label2.Text = counter.ToString();
            btStart.Enabled = false;
            btStop.Enabled = true;
            label2.ForeColor = Color.White;

            label1.Text = "";
            counter = 0;
        }

        private void Tcount_Tick(object sender, EventArgs e)
        {
            counter++;
            if (counter == 0)
                Tcount.Stop();
            label2.Text = counter.ToString();
        }

        private void btStop_Click(object sender, EventArgs e)
        {
            label1.Text = "The Count is: " + label2.Text;
            label1.Visible = true;
            Tcount.Stop();

            label2.Text = "0";
        
            counter = 0;
            btStop.Enabled = false;
            btStart.Enabled = true;   
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
        }
    }
}
